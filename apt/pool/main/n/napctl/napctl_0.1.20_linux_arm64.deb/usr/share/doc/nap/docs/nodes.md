# Nodes

`napctl` is designed to manage one or more agents. A node is one host where `napd` runs.

Local node:

```yaml
nodes:
  local:
    type: local
    default: true
    socket: /tmp/napd.sock
```

Remote node:

```yaml
nodes:
  ubuntu-gpu:
    type: remote
    url: https://ubuntu.example.com:8788
    token_env: NAP_UBUNTU_TOKEN
```

Remote nodes require either `token_env` or `token`. Prefer `token_env` for real
deployments so bearer tokens stay in the shell, launchd, systemd, or secret
manager rather than in `nap.yaml`.

Current status:

- local nodes over Unix sockets are implemented
- remote node config and client selection are implemented
- remote agent listener with bearer token validation is implemented
- TLS setup is supported either through a reverse proxy or directly in `napd`

Commands:

```sh
napctl node ls
napctl node status
napctl node status --json
napctl node plan ollama
napctl node plan ollama --json
napctl node start ollama
napctl node start ollama --json
napctl node inspect local
napctl node add local --name local --socket-path /tmp/napd.sock
napctl node add remote --name ubuntu-gpu --url https://ubuntu.example.com:8788 --token-env NAP_UBUNTU_TOKEN
napctl node add remote --name ubuntu-gpu --url https://ubuntu.example.com --token-env NAP_UBUNTU_TOKEN --write
napctl --node ubuntu-gpu host inspect
napctl --node local service ls
napctl --node ubuntu-gpu doctor
```

Without `--write`, `node add` prints a YAML snippet. With `--write`, it updates
the selected config file and validates it before returning.

Remote agent example on Ubuntu:

Generate a bearer token:

```sh
napctl token --env NAP_REMOTE_TOKEN
```

```yaml
agent:
  socket: /run/nap/napd.sock
  remote:
    listen: 127.0.0.1:8788
    token_env: NAP_REMOTE_TOKEN
```

Run:

```sh
NAP_REMOTE_TOKEN='generated-value' napd --config /etc/nap/nap.yaml
```

Then expose `127.0.0.1:8788` through Caddy/Nginx with HTTPS, and configure the MacBook:

```yaml
nodes:
  ubuntu-gpu:
    type: remote
    url: https://ubuntu.example.com
    token_env: NAP_UBUNTU_TOKEN
```

The target deployment model is:

```text
MacBook
  napctl
    |
    v
Ubuntu server
  napd + gateway + Docker
```

Linux support target:

- Ubuntu is the first reference platform.
- Other systemd-based distributions should work if Docker Engine and the required GPU tooling are available.
- Non-systemd distributions are not excluded, but will need separate service templates later.
