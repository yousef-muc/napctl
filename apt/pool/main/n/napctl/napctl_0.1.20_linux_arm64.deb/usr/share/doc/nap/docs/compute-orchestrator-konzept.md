# Konzept: Go-basierter Local/Edge Compute Orchestrator

## Kurzbeschreibung

Dieses Projekt ist ein Open-Source-Tool in Go, das Docker-Workloads bei Bedarf automatisch startet und nach einer definierten Idle-Zeit wieder stoppt. Der Fokus liegt auf lokalen und privaten Compute-Ressourcen, insbesondere AI-Workloads wie Ollama, vLLM, ComfyUI, Whisper, eigene AI-APIs, aber auch normale Webservices und Development-Services.

Das Tool soll bestehende Reverse-Proxies wie Caddy, Nginx, Apache oder Traefik nicht ersetzen, sondern sich sauber dahinter oder daneben integrieren. Es bringt "wake-on-request", Healthcheck-Waiting, Reverse Proxying, Idle Shutdown, Resource Monitoring und Multi-Node-Verwaltung in vorhandene Docker-Setups.

Die erste ernsthafte Produktoberfläche ist eine schöne CLI/TUI. Eine Web UI ist erst später geplant.

## Arbeitstitel und Namensidee

Der Name ist noch offen. "Nova" war der erste Arbeitstitel, ist aber sehr generisch und bereits stark belegt, unter anderem durch OpenStack Nova und verschiedene AI-/CLI-Projekte.

Eine gewünschte Namensrichtung ist wie bei `kubectl`, `systemctl` oder `launchctl`: ein kurzer Projektname plus `ctl` fuer das Steuerwerkzeug.

Beispielhafte Struktur:

```text
Projektname: Nap
CLI:         napctl
Daemon:      napd
Config:      nap.yaml
```

Weitere moegliche Richtungen:

```text
napctl
wakectl
idlectl
dozectl
somnactl
snoozectl
```

Wichtig: Vor einer finalen Entscheidung sollten GitHub-Organisation, Domain, Homebrew-Formel, Paketnamen und moegliche Markenkonflikte recherchiert werden.

## Produktziel

Das Ziel ist ein production-ready Open-Source-Compute-Orchestrator fuer Docker-Workloads auf lokalen Maschinen, privaten Servern und entfernten Hosts.

Das Tool soll:

- Docker-Container bei HTTP-Requests automatisch starten
- auf Healthchecks warten, bevor Traffic weitergeleitet wird
- Requests an den Zielservice weiterleiten
- Services nach konfigurierbarer Idle-Zeit stoppen
- CPU/RAM/GPU/VRAM beobachten
- lokale und remote Hosts verwalten
- mehrere Nodes unterstuetzen
- bestehende Reverse-Proxy-Setups respektieren
- eine sehr gute CLI/TUI-Erfahrung bieten

## Zielplattformen

Fokus fuer v1:

- Linux
- macOS

Spaeter:

- Windows

Linux ist die wichtigste Runtime-Plattform, weil Docker Engine, NVIDIA-GPUs, AMD-GPUs und systemd dort am saubersten funktionieren.

macOS soll ebenfalls frueh unterstuetzt werden, insbesondere fuer lokale Entwicklung mit Docker Desktop oder Colima. GPU-/VRAM-Funktionen sind auf macOS fuer Container jedoch deutlich eingeschraenkter.

Windows kann spaeter folgen, zuerst eventuell als CLI-Client und danach als vollwertiger Agent ueber Docker Desktop/WSL.

## Typische Szenarien

### Szenario 1: Lokal

Eine Anwendung auf Mac, Linux oder spaeter Windows ruft einen lokalen Service auf. Das Tool laeuft auf derselben Maschine, ueberwacht Docker-Container und startet oder stoppt diese je nach Bedarf.

```text
Lokale App / Browser / API Client
        |
        v
Gateway / Agent auf derselben Maschine
        |
        v
Docker Container
```

### Szenario 2: LAN

Eine Anwendung laeuft lokal auf dem MacBook, Linux-Desktop oder Windows-Rechner. Die eigentlichen Workloads laufen auf einem oder mehreren Ubuntu-Servern im privaten Netzwerk.

```text
MacBook / Desktop App
        |
        v
Ubuntu Server im LAN
        |
        v
Agent + Gateway + Docker + GPU Workloads
```

### Szenario 3: Internet

Eine lokale Anwendung ruft einen Server im Internet auf, auf dem das Tool laeuft. Der Server nimmt Requests an, startet bei Bedarf Container und leitet Traffic weiter.

```text
App / Browser / API Client
        |
        v
https://ai.example.com
        |
        v
Server mit Agent + Gateway + Docker
```

### Szenario 4: Server zu Server

Eine oder mehrere Anwendungen laufen auf Servern und rufen andere Services auf demselben oder auf anderen Servern auf. Auch hier kann Wake-on-request und Idle Shutdown greifen.

```text
Service A
   |
   v
Gateway auf Server B
   |
   v
Service B Container
```

## Kernidee: Request-gesteuertes Starten

Beispiel:

```text
Request an ollama.example.com
        |
        v
Gateway erkennt Service "ollama"
        |
        v
Container laeuft?
        |
        +-- ja --> Request weiterleiten
        |
        +-- nein --> Container starten
                    |
                    v
                Healthcheck abwarten
                    |
                    v
                Request weiterleiten
                    |
                    v
                Idle-Timer aktualisieren
                    |
                    v
                Nach z. B. 5 Minuten ohne Traffic stoppen
```

## Hauptkomponenten

### CLI/TUI

Die CLI ist die Hauptoberflaeche des Produkts.

Beispielname:

```text
napctl
```

Aufgaben:

- initialisieren
- Services konfigurieren
- Nodes verwalten
- Services starten/stoppen
- Logs anzeigen
- Status anzeigen
- Diagnose ausfuehren
- interaktives Dashboard anzeigen

Technologien:

- Cobra fuer Commands und Flags
- Bubble Tea fuer interaktive TUI
- Lip Gloss fuer Styling
- Bubbles fuer Tabellen, Listen, Spinner, Inputs

Beispielcommands:

```text
napctl init
napctl install
napctl doctor
napctl config validate

napctl node add
napctl node ls
napctl node inspect <node>

napctl service add
napctl service ls
napctl service inspect <service>
napctl service start <service>
napctl service stop <service>
napctl service restart <service>
napctl service logs <service>

napctl top
```

Wichtig:

- CLI soll fuer Menschen schoen sein
- CLI soll auch scriptbar sein
- JSON-Ausgaben fuer Automation sollten moeglich sein

Beispiele:

```text
napctl service ls --json
napctl node ls --json
napctl service inspect ollama --json
```

### Agent / Daemon

Der Agent ist der Hintergrunddienst auf einem Host.

Beispielname:

```text
napd
```

Aufgaben:

- Config laden
- lokale Services verwalten
- Docker steuern
- Service-Zustand verfolgen
- Healthchecks pruefen
- Idle-Timer verwalten
- Metrics sammeln
- Control API fuer CLI bereitstellen
- Gateway-Requests koordinieren

Der Agent laeuft dort, wo Docker und die Container laufen.

### Gateway

Das Gateway ist der HTTP-Eingang fuer schlafbare Services.

Aufgaben:

- HTTP-Requests annehmen
- Service anhand von Hostname und optional Pfad erkennen
- Start bei Bedarf ausloesen
- auf Healthcheck warten
- Request an Zielservice weiterleiten
- Idle-Aktivitaet aktualisieren
- Fehler sauber zurueckgeben, wenn Service nicht startet

Das Gateway kann im selben Prozess wie der Agent laufen, sollte intern aber sauber als eigene Komponente strukturiert sein.

### Runtime

Die Runtime-Komponente spricht mit Docker.

Aufgaben:

- Container inspect
- Container start
- Container stop
- Container status
- Container logs
- Docker stats

Fuer v1 ist Docker die Runtime. Andere Runtimes wie Podman oder containerd koennen spaeter geprueft werden.

### Metrics

Metrics liest System- und Container-Ressourcen aus.

Zielwerte:

- CPU
- RAM
- Container CPU/RAM
- NVIDIA GPU/VRAM
- AMD GPU/VRAM, soweit stabil moeglich

Linux ist hier die wichtigste Plattform. Auf macOS sind GPU-/VRAM-Daten fuer Container vermutlich begrenzt.

### Scheduler

Der Scheduler entscheidet, ob und wann Services gestartet oder gestoppt werden.

In v1 zunaechst:

- darf Service starten?
- ist Service idle?
- soll Service gestoppt werden?
- gibt es Start-/Stop-Timeouts?
- gibt es einfache Prioritaeten?

Spaeter:

- bessere Ressourcenplanung
- GPU-/VRAM-basierte Entscheidungen
- Preemption, z. B. idle Ollama stoppen, um ComfyUI zu starten
- Multi-node Placement

### Config

Die Konfiguration sollte deklarativ und gut lesbar sein.

Beispiel:

```yaml
gateway:
  listen: 127.0.0.1:8787

services:
  ollama:
    host: ollama.example.com
    container: ollama
    target: http://127.0.0.1:11434
    healthcheck:
      url: http://127.0.0.1:11434/api/tags
      timeout: 60s
      interval: 1s
    idle: 5m
    stop_timeout: 30s

  comfyui:
    host: comfy.example.com
    container: comfyui
    target: http://127.0.0.1:8188
    healthcheck:
      url: http://127.0.0.1:8188/
      timeout: 120s
      interval: 2s
    idle: 10m
    stop_timeout: 60s
```

## Integration mit bestehenden Reverse Proxies

Eine zentrale Produktentscheidung:

> Das Tool ersetzt Caddy, Nginx, Apache oder Traefik nicht, sondern ergaenzt sie um Wake-on-request, Idle Shutdown und Compute-Ressourcensteuerung.

Viele private Nutzer und Unternehmen haben bereits fertige Setups mit TLS, Domains, Firewalls und Routing. Deshalb soll das Tool flexibel dahinter oder daneben laufen.

### Modus 1: Reverse Proxy Mode

Caddy, Nginx, Apache oder Traefik bleibt vorne auf Port 80/443. Das neue Tool laeuft intern auf einem Port wie `127.0.0.1:8787`.

```text
Internet / LAN
        |
        v
Caddy / Nginx / Apache / Traefik
        |
        v
Gateway des Tools
        |
        v
Docker Container
```

Beispiel Caddy:

```caddyfile
ollama.example.com {
    reverse_proxy 127.0.0.1:8787
}

comfy.example.com {
    reverse_proxy 127.0.0.1:8787
}
```

Das Gateway erkennt anhand des Host-Headers, welcher Service gemeint ist.

Wichtig:

```text
Richtig:
Caddy -> Gateway -> Container

Falsch fuer Wake-on-request:
Caddy -> Container direkt
```

Wenn Caddy direkt zum Container routet, kann das Tool den Container nicht vorher starten.

### Modus 2: Sidecar Mode

Das Tool kann auch wie ein vorgeschalteter Sidecar pro Workload genutzt werden. Das ist besonders nuetzlich in bestehenden Docker-Compose- oder Server-Setups.

```text
Bestehendes Setup vorher:
Reverse Proxy -> Container-Port

Bestehendes Setup nachher:
Reverse Proxy -> Tool-Gateway -> Container-Port
```

Der Nutzer muss nicht das gesamte Setup umbauen, sondern kann einzelne Services schrittweise migrieren.

### Modus 3: Direct Mode

Clients koennen das Gateway auch direkt aufrufen, ohne Caddy/Nginx davor.

```text
App / Browser / API Client
        |
        v
Gateway
        |
        v
Docker Container
```

Das ist besonders fuer lokale Entwicklung, Tests und einfache Homelab-Setups praktisch.

## Multi-Node-Konzept

Community v1 soll Multi-node nicht kuenstlich ausschliessen. Private Nutzer koennen mehrere Server haben, z. B. Ubuntu-Server mit NVIDIA-GPU und andere mit AMD-GPU.

Begriffe:

```text
Node:
Ein Host, auf dem Agent + Docker laufen.

Agent:
Der Daemon auf einem Node.

Gateway:
HTTP-Eingang fuer schlafbare Services auf einem Node.

CLI:
Das Werkzeug des Nutzers, das lokale oder entfernte Agents steuert.
```

Ein pragmatischer v1-Ansatz:

```text
MacBook
└── napctl
    ├── ubuntu-gpu-nvidia
    ├── ubuntu-gpu-amd
    └── mac-local
```

Das bedeutet: `napctl` kennt mehrere Agents und kann sie verwalten. Ein zentraler Controller kann spaeter entstehen, ist aber fuer v1 nicht zwingend erforderlich.

Spaeteres Zielbild:

```text
napctl
   |
   v
Controller
   |
   +--> Agent Node A -> Docker
   +--> Agent Node B -> Docker
   +--> Agent Node C -> Docker
```

## Sicherheit

RBAC, Teamverwaltung und Enterprise Permission Models sind fuer dieses Projekt am Anfang zu ueberdimensioniert und sollen nicht Teil von v1 sein.

Stattdessen:

### Lokal

```text
CLI -> Unix Socket -> lokaler Agent
```

Zugriff wird ueber Betriebssystemrechte geregelt.

### Remote

```text
CLI -> HTTPS/TLS -> Remote Agent
```

Moegliche Sicherheitsmodelle:

- Access Token
- mTLS
- spaeter optional read-only Token

Grundregel fuer v1:

```text
Entweder du hast Zugriff auf den Agent, oder nicht.
```

Kein RBAC in v1:

- keine Rollen
- keine Teamverwaltung
- kein SSO/OIDC
- kein Enterprise-Rechtemodell

## Community Edition und Pro-Idee

Die Community Edition soll nicht kuenstlich eingeschraenkt werden. Auch private Nutzer sollen starke Funktionen wie Multi-node, Remote Agents, GPU-Monitoring und Scheduling verwenden koennen.

Community v1:

- Linux + macOS Fokus
- Docker Runtime
- Direct Mode
- Reverse Proxy Mode
- Sidecar Mode
- Wake-on-request
- Idle Shutdown
- Healthchecks
- schoene CLI
- TUI Dashboard
- Logs
- Doctor/Diagnostics
- CPU/RAM Metrics
- NVIDIA GPU Metrics
- AMD GPU Detection/Metrics soweit stabil moeglich
- Remote Agents
- Multi-node Verwaltung
- Basic Scheduling
- sichere Agent-Kommunikation
- GitHub Releases
- Homebrew
- `.deb` / `.rpm`

Nicht v1:

- Web UI
- RBAC
- Teamverwaltung
- SSO/OIDC
- Enterprise Permission Model
- Kubernetes
- Cluster-Control-Plane im Kubernetes-Sinn
- Billing
- eigener Container Runtime

Pro / Business spaeter:

- Enterprise Support
- kommerzielle Supportvertraege
- garantierte Reaktionszeiten
- professionelle Onboarding-Dokumentation
- signierte Enterprise Builds
- eventuell gehosteter Fleet-/Update-Service
- Audit-/Compliance-Features nur wenn wirklich nachgefragt

Die Pro-Version soll nicht dadurch wertvoll sein, dass Kernfunktionen aus der Community-Version entfernt werden. Wert entsteht durch Support, Verlaesslichkeit, kommerzielle Nutzung, Komfort und Unternehmensanforderungen.

## CLI-Design

Die CLI soll ein Hauptmerkmal des Produkts sein.

Beispiele:

```text
napctl init
napctl doctor
napctl install
napctl config validate

napctl service add --interactive
napctl service ls
napctl service inspect ollama
napctl service start ollama
napctl service stop ollama
napctl service logs ollama

napctl node add ubuntu-gpu-1
napctl node ls
napctl node inspect ubuntu-gpu-1

napctl top
```

Beispiel fuer `napctl top`:

```text
╭─ NAP ──────────────────────────────────────────╮
│                                                │
│ CPU   ███████░░░ 68%     RAM   18 / 32 GB     │
│ GPU   ████░░░░░░ 37%     VRAM   6 / 16 GB     │
│                                                │
├────────────────────────────────────────────────┤
│ SERVICE       STATE       RAM       VRAM       │
│                                                │
│ ● postgres    running     812 MB       -       │
│ ● ollama      running     3.2 GB     6.1 GB    │
│ ○ comfyui     sleeping       -         -       │
│ ○ whisper     sleeping       -         -       │
│                                                │
├────────────────────────────────────────────────┤
│ ↑↓ Select   ↵ Details   S Start/Stop   Q Quit  │
╰────────────────────────────────────────────────╯
```

## Go-Projektstruktur

Vorgeschlagene Struktur:

```text
project/
├── cmd/
│   ├── root.go
│   ├── init.go
│   ├── install.go
│   ├── doctor.go
│   ├── config.go
│   ├── node.go
│   ├── service.go
│   └── top.go
│
├── internal/
│   ├── agent/
│   ├── api/
│   ├── config/
│   ├── gateway/
│   ├── metrics/
│   ├── runtime/
│   │   └── docker/
│   ├── scheduler/
│   ├── service/
│   └── state/
│
├── tui/
│   ├── dashboard.go
│   ├── services.go
│   └── components/
│
├── docs/
│   ├── caddy.md
│   ├── nginx.md
│   ├── apache.md
│   ├── traefik.md
│   └── security.md
│
├── examples/
│   ├── docker-compose/
│   ├── caddy/
│   ├── nginx/
│   └── systemd/
│
├── go.mod
├── go.sum
├── README.md
└── goreleaser.yaml
```

Wichtige Architekturregel:

```text
CLI/TUI und Core strikt trennen.
```

Der Core soll spaeter auch von anderen Oberflaechen genutzt werden koennen:

- REST API
- Web UI
- zentraler Controller
- kommerzielle Erweiterungen

## Release-Plan Richtung Production-Ready v1

Nicht als "Demo-MVP" denken, sondern als geplante Schritte zu einer ernsthaften v1.

### Phase 0.1: Foundation

- Go-Projektstruktur
- CLI-Grundgeruest mit Cobra
- Config-Modell
- Config laden/validieren
- Docker Runtime Basis
- Service-Status
- manuelles Start/Stop
- Logs
- Doctor-Kommando

### Phase 0.2: Gateway

- HTTP Gateway
- Host-basiertes Routing
- Wake-on-request
- Healthcheck Wait
- Reverse Proxy Weiterleitung
- Idle Tracking
- saubere Fehlerantworten

### Phase 0.3: Production Runtime

- systemd Service fuer Linux
- macOS LaunchAgent/LaunchDaemon-Konzept
- strukturierte Logs
- graceful shutdown
- Timeouts
- Config Reload
- robuste Fehlerzustaende

### Phase 0.4: Proxy Integrations

- Caddy-Beispiele
- Nginx-Beispiele
- Apache-Beispiele
- Traefik-Beispiele
- Direct Mode Dokumentation
- Sidecar Mode Dokumentation
- Docker Compose Beispiele

### Phase 0.5: Metrics

- CPU/RAM Monitoring
- Docker Stats
- NVIDIA GPU/VRAM ueber `nvidia-smi` oder NVML
- AMD GPU Detection/Metrics, soweit stabil moeglich
- `napctl top` TUI

### Phase 0.6: Security

- lokale Socket-Kommunikation
- Remote Agent API
- HTTPS/TLS
- Access Token oder mTLS
- Secrets nicht in Logs
- Security-Dokumentation

### Phase 0.7: Multi-Node

- CLI kann mehrere Nodes verwalten
- Remote Agents registrieren
- Status ueber mehrere Nodes
- Service-Zuordnung zu Nodes
- Basic Scheduling

### Phase 1.0: Production Ready

- stabile Config
- stabile CLI
- stabile Agent API
- gute Dokumentation
- GitHub Releases
- GoReleaser
- Homebrew Tap
- `.deb` / `.rpm`
- Checksums und Signaturen, soweit sinnvoll
- Tests
- Upgrade-Pfad
- klare Beispiele fuer reale Setups

## Distribution

Geplante Distributionswege:

Linux:

- `.deb`
- `.rpm`
- systemd Service
- GitHub Release Binary

macOS:

- Homebrew Tap
- GitHub Release Binary
- LaunchAgent/LaunchDaemon Anleitung

Generell:

- GoReleaser
- Checksums
- Release Notes
- Beispielconfigs

## Wichtigster Produktsatz

> Das Tool ersetzt nicht deinen Reverse Proxy. Es macht bestehende Docker-Services wake-on-request-faehig und legt sie nach Inaktivitaet schlafen.

## Zweiter Produktsatz

> Die CLI steuert den Agent, der Agent steuert Docker, und das Gateway ist der HTTP-Eingangspunkt fuer schlafbare Services.

## Startauftrag fuer einen neuen Codex-Chat

Wenn dieses Konzept in einem neuen Chat verwendet wird, koennte der Startprompt lauten:

```text
Wir bauen ein neues Open-Source-Go-Projekt basierend auf dem folgenden Konzept.

Bitte starte mit:
1. einer sinnvollen Go-Projektstruktur,
2. Cobra CLI Grundgeruest,
3. Config-Modell und YAML-Loader,
4. Docker Runtime Interface,
5. erstem `doctor`, `service ls`, `service start`, `service stop`,
6. sauberer Trennung von CLI und Core.

Noch keine Web UI. Fokus auf production-ready Architektur, gute Fehlerbehandlung und spaetere Erweiterbarkeit fuer Gateway, Metrics und Multi-node.
```

