# Lokaler Test: MacBook napctl + Ubuntu-Server blackwell

Diese Anleitung ist fuer deinen ersten echten lokalen Test mit:

- MacBook: nur `napctl` Client und TUI
- Ubuntu 24.04 Server `blackwell`: `napd`, Docker, Gateway, GPU Scheduling
- Server-IP: `192.168.2.211`
- GPU: RTX Blackwell 4000, 24 GB VRAM
- RAM: 48 GB
- vorhandene Docker-Container:
  - Flux: Container `flux`, Host-Port `8092 -> 8080`
  - Qwen 2.1 Image: Container `qwen`, Host-Port `8093 -> 8080`

Das Paket heisst `napctl` und installiert immer beide Binaries:

- `napctl`
- `napd`

Auf dem MacBook verwenden wir nur `napctl`. Auf `blackwell` laeuft `napd` als
systemd-Service.

## Was Nap In Deinem Setup Kann

Aktuell verwaltet Nap existierende Docker-Container per:

```text
docker start <container>
docker stop <container>
docker inspect <container>
docker logs <container>
```

Das bedeutet:

- Nap fuehrt aktuell kein `docker compose up` aus.
- Nap fuehrt aktuell kein `docker compose down` aus.
- Die Container `flux` und `qwen` muessen vorher existieren.
- Bitte spaeter nicht mehr `docker compose down` fuer den normalen Wechsel
  verwenden, weil `down` Container entfernen kann.
- Verwende fuer den Nap-Test stattdessen `docker stop flux qwen` oder
  `docker compose stop`.

Der erste sinnvolle Zielzustand ist:

```text
/opt/ai/compose/flux   -> Container flux wurde einmal erzeugt
/opt/ai/compose/qwen   -> Container qwen wurde einmal erzeugt
napd                   -> startet/stoppt diese Container nach Bedarf
```

Wenn ein Container noch nie erzeugt wurde, einmalig:

```sh
cd /opt/ai/compose/flux
docker compose up -d
docker stop flux

cd /opt/ai/compose/qwen
docker compose up -d
docker stop qwen
```

Danach sollte gelten:

```sh
docker ps -a --format 'table {{.Names}}\t{{.Status}}\t{{.Ports}}'
```

Erwartet:

```text
flux   Exited ... oder Up ...   0.0.0.0:8092->8080/tcp
qwen   Exited ... oder Up ...   0.0.0.0:8093->8080/tcp
```

## Wie Nap Ressourcen Verwaltet

Nap weiss nicht von selbst, dass Flux und Qwen viel VRAM brauchen. Das geben wir
in `/etc/nap/nap.yaml` ueber `resources` an.

Nap entscheidet dann beim Start eines Services:

1. Welche CPU/RAM/GPU-Anforderungen hat der angeforderte Service?
2. Wie viel RAM/VRAM ist laut Host-Inspektion frei oder belegt?
3. Welche anderen konfigurierten GPU-Services laufen?
4. Sind diese Services idle?
5. Darf ein idle Service gestoppt werden, um Platz zu schaffen?

Bei dir ist besonders wichtig:

- `flux` und `qwen` sind beide in `nap.yaml` als Services eingetragen.
- Beide haben GPU-Anforderungen.
- Beide nutzen dieselbe GPU `0`.
- Wenn Flux laeuft und Qwen angefordert wird, kann Nap Flux stoppen, wenn Flux
  aus Nap-Sicht idle ist oder als Preemption-Kandidat gilt.

## Bestehendes Caddy-Setup

Du hast aktuell Caddy fuer deine normalen Anwendungen:

```text
http://192.168.2.211/flux/generate -> 127.0.0.1:8092
http://192.168.2.211/qwen          -> 127.0.0.1:8093
```

Dieses Caddy-Setup kann parallel bestehen bleiben.

Nap Gateway arbeitet aktuell primaer hostbasiert. Fuer den Test verwenden wir
deshalb eigene Hostnamen ueber den `Host` Header:

```text
flux.nap.local -> napd gateway -> 127.0.0.1:8092
qwen.nap.local -> napd gateway -> 127.0.0.1:8093
```

Der Nap-Gateway-Port ist in dieser Anleitung `8787`. Das vermeidet Konflikte
mit Caddy auf Port `80`.

## 1. MacBook: napctl Installieren Oder Aktualisieren

Auf dem MacBook:

```sh
brew tap yousef-muc/tap
brew update
brew upgrade napctl || brew install napctl
napctl version
napd --version
```

Fuer den Split-Test soll auf dem MacBook kein lokaler `napd` laufen:

```sh
brew services list | grep napctl || true
brew services stop napctl || true
```

## 2. blackwell: Paket Installieren

Auf `blackwell`:

```sh
curl -fsSL https://yousef-muc.github.io/napctl/install.sh | sh
napctl version
napd --version
```

Falls du lieber manuell installierst:

```sh
sudo install -d -m 0755 /usr/share/keyrings
curl -fsSL https://yousef-muc.github.io/napctl/apt/gpg/napctl.gpg | sudo tee /usr/share/keyrings/napctl-archive-keyring.gpg >/dev/null
echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/napctl-archive-keyring.gpg] https://yousef-muc.github.io/napctl/apt stable main" | sudo tee /etc/apt/sources.list.d/napctl.list >/dev/null
sudo apt update
sudo apt install napctl
```

## 3. blackwell: Docker Und GPU Pruefen

Auf `blackwell`:

```sh
napctl version
napd --version
sudo systemctl status napd --no-pager
sudo napctl --config /etc/nap/nap.yaml config validate
sudo napctl --config /etc/nap/nap.yaml --socket /run/nap/napd.sock doctor
sudo napctl --config /etc/nap/nap.yaml --socket /run/nap/napd.sock host inspect
sudo napctl --config /etc/nap/nap.yaml --socket /run/nap/napd.sock service ls
hostname
hostname -I
docker version
docker ps -a --format 'table {{.Names}}\t{{.Status}}\t{{.Ports}}'
nvidia-smi
```

Dein aktueller Stand nach der Paketinstallation ist gut:

- `napctl 0.1.3` und `napd 0.1.3` sind installiert.
- `napd.service` ist `active (running)`.
- `config validate` ist `ok`.
- `doctor` sieht Socket und Gateway.
- `host inspect` sieht Docker, 24 CPUs, 46.2 GiB RAM und die NVIDIA RTX PRO
  4000 Blackwell GPU mit 23.9 GiB VRAM.

Wichtig ist die leere Ausgabe hier:

```text
sudo napctl --config /etc/nap/nap.yaml --socket /run/nap/napd.sock service ls

SERVICE              STATE        CONTAINER                TARGET
```

Das bedeutet: `napd` laeuft korrekt, aber `/etc/nap/nap.yaml` enthaelt noch
keine `services`. Das ist der naechste Schritt. Erst nachdem `flux` und
`qwen-image` in der Config stehen und `napd` neu gestartet wurde, kann Nap diese
Container anzeigen, planen, starten, stoppen und im Gateway routen.

Auch diese Zeile aus `systemctl status` ist fuer den naechsten Schritt wichtig:

```text
agent gateway listening addr=127.0.0.1:8787
```

Fuer lokale Tests direkt vom MacBook muss der Gateway spaeter auf
`0.0.0.0:8787` lauschen. Fuer Remote-Steuerung vom MacBook brauchen wir
zusaetzlich `NAP_REMOTE_LISTEN=0.0.0.0:8788` in `/etc/nap/napd.env`.

Pruefen, ob der Paket-User `nap` Docker und NVIDIA sehen kann:

```sh
id nap
sudo -u nap docker ps
sudo -u nap nvidia-smi
```

Wenn Docker-Zugriff fehlschlaegt:

```sh
sudo usermod -aG docker nap
sudo systemctl restart napd || true
```

Wenn `sudo -u nap nvidia-smi` fehlschlaegt, bitte die genaue Fehlermeldung
notieren. Das ist fuer spaetere GPU-Debugging-Arbeit wichtig.

## 4. blackwell: Container Vorbereiten

Zuerst sicherstellen, dass beide Container existieren:

```sh
docker ps -a --format 'table {{.Names}}\t{{.Status}}\t{{.Ports}}'
```

Wenn `qwen` noch nicht existiert:

```sh
cd /opt/ai/compose/qwen
docker compose up -d
docker stop qwen
```

Wenn `flux` noch nicht existiert:

```sh
cd /opt/ai/compose/flux
docker compose up -d
docker stop flux
```

Fuer den kontrollierten Test beide Container stoppen:

```sh
docker stop flux qwen || true
nvidia-smi
```

Wichtig: Nicht `docker compose down` verwenden, solange Nap die Container
verwalten soll. `down` kann den Container entfernen; Nap braucht aber einen
existierenden Container, den es mit `docker start` starten kann.

## 5. blackwell: Health URLs Finden

Flux ist ueber Host-Port `8092` erreichbar:

```sh
curl -i http://127.0.0.1:8092/
curl -i http://127.0.0.1:8092/generate
```

Qwen ist ueber Host-Port `8093` erreichbar:

```sh
curl -i http://127.0.0.1:8093/
```

Nap betrachtet nur HTTP `2xx` und `3xx` als gesund. Wenn `/` oder `/generate`
`404` liefert, brauchen wir einen besseren Healthcheck-Pfad.

Startwerte fuer diese Anleitung:

```text
Flux target:  http://127.0.0.1:8092
Flux health:  http://127.0.0.1:8092/
Qwen target:  http://127.0.0.1:8093
Qwen health:  http://127.0.0.1:8093/
```

Wenn einer davon nicht `2xx` oder `3xx` liefert, ersetze ihn in der Config.

## 6. Remote Token Erzeugen

Auf dem MacBook oder auf `blackwell`:

```sh
napctl token --env NAP_REMOTE_TOKEN
```

Den generierten Tokenwert auf `blackwell` in `/etc/nap/napd.env` eintragen:

```sh
sudo tee /etc/nap/napd.env >/dev/null <<'EOF'
NAP_LOG_LEVEL=debug
NAP_REMOTE_TOKEN=replace-with-generated-token
NAP_REMOTE_LISTEN=0.0.0.0:8788
NAP_REMOTE_TOKEN_ENV=NAP_REMOTE_TOKEN
EOF
sudo chmod 0600 /etc/nap/napd.env
```

Fuer den ersten lokalen LAN-Test ist `0.0.0.0:8788` okay. Danach sollten wir das
haerten, z. B. ueber Caddy HTTPS oder Firewall-Einschraenkung.

Falls `ufw` aktiv ist:

```sh
sudo ufw allow from <macbook-lan-ip> to any port 8788 proto tcp
sudo ufw allow from <macbook-lan-ip> to any port 8787 proto tcp
```

## 7. blackwell: /etc/nap/nap.yaml Schreiben

Auf `blackwell`:

```sh
sudo nano /etc/nap/nap.yaml
```

Startkonfiguration:

```yaml
agent:
  socket: /run/nap/napd.sock
  remote:
    listen: ""
    token_env: NAP_REMOTE_TOKEN
    cert_file: ""
    key_file: ""

nodes:
  local:
    type: local
    default: true
    socket: /run/nap/napd.sock

gateway:
  listen: 0.0.0.0:8787

services:
  flux:
    host: flux.nap.local
    container: flux
    target: http://127.0.0.1:8092
    healthcheck:
      url: http://127.0.0.1:8092/
      timeout: 180s
      interval: 2s
    resources:
      memory: 16GiB
      gpus:
        count: 1
        vendor: nvidia
        min_vram: 14GiB
    idle: 3m
    stop_timeout: 45s

  qwen-image:
    host: qwen.nap.local
    container: qwen
    target: http://127.0.0.1:8093
    healthcheck:
      url: http://127.0.0.1:8093/
      timeout: 240s
      interval: 2s
    resources:
      memory: 24GiB
      gpus:
        count: 1
        vendor: nvidia
        min_vram: 18GiB
    idle: 3m
    stop_timeout: 45s
```

Warum diese Werte?

- Deine GPU hat 24 GB VRAM.
- `flux` und `qwen` werden wahrscheinlich nicht beide stabil gleichzeitig in den
  VRAM passen.
- `min_vram` ist absichtlich so gesetzt, dass Nap bei belegtem VRAM ueber
  Preemption nachdenken muss.
- Die Werte sind Startwerte. Wenn `service plan` falsche Entscheidungen trifft,
  passen wir sie nach echter Messung mit `nvidia-smi` an.

Config validieren:

```sh
sudo napctl --config /etc/nap/nap.yaml config validate
```

Service starten:

```sh
sudo systemctl enable --now napd
sudo systemctl restart napd
sudo systemctl status napd --no-pager
```

Logs offen lassen:

```sh
sudo journalctl -u napd -f
```

## 8. MacBook: Remote Node Konfigurieren

Auf dem MacBook:

```sh
export NAP_BLACKWELL_TOKEN='replace-with-generated-token'
mkdir -p "$HOME/Library/Application Support/nap"
cat > "$HOME/Library/Application Support/nap/nap.yaml" <<'EOF'
nodes:
  blackwell:
    type: remote
    default: true
    url: http://192.168.2.211:8788
    token_env: NAP_BLACKWELL_TOKEN
EOF
```

Pruefen:

```sh
napctl config path
napctl node ls
napctl --node blackwell doctor
napctl --node blackwell host inspect
napctl --node blackwell service ls
```

Erwartung:

- `doctor` verbindet sich mit `blackwell`.
- `host inspect` zeigt Docker und die NVIDIA GPU.
- `service ls` zeigt `flux` und `qwen-image`.

## 9. MacBook: TUI Oeffnen

Auf dem MacBook:

```sh
export NAP_BLACKWELL_TOKEN='replace-with-generated-token'
napctl --node blackwell
```

Im TUI:

- `/` oeffnet die Command Palette.
- `/doctor`
- `/service ls`
- `/service inspect flux`
- `/service inspect qwen-image`
- `/service plan qwen-image`

Wenn die UI springt, abschneidet oder unklar ist: Screenshot machen und
Terminalgroesse notieren.

## 10. Kontrollierter Flux -> Qwen Test

Auf `blackwell` beide Container stoppen:

```sh
docker stop flux qwen || true
nvidia-smi
```

Vom MacBook Flux ueber Nap Gateway wecken:

```sh
curl -v -H 'Host: flux.nap.local' http://192.168.2.211:8787/generate
```

Falls Flux fuer `/generate` zwingend `POST` oder JSON braucht, nutze denselben
Request wie deine echte Anwendung, aber mit:

```text
URL:  http://192.168.2.211:8787/generate
Host: flux.nap.local
```

Danach pruefen:

```sh
napctl --node blackwell service ls
napctl --node blackwell service inspect flux
napctl --node blackwell host inspect
```

Auf `blackwell`:

```sh
docker ps --format 'table {{.Names}}\t{{.Status}}\t{{.Ports}}'
nvidia-smi
```

Jetzt Flux idle werden lassen. In der Beispielconfig sind es `3m`:

```sh
sleep 200
```

Dann Qwen ueber Nap Gateway anfordern:

```sh
curl -v -H 'Host: qwen.nap.local' http://192.168.2.211:8787/
```

Wenn deine echte Qwen-Anfrage einen anderen Pfad oder `POST` verwendet, denselben
Request wie aus deiner Anwendung verwenden, aber:

```text
URL:  http://192.168.2.211:8787/<qwen-pfad>
Host: qwen.nap.local
```

Erwartung:

- Qwen-Request erreicht Nap Gateway.
- Nap sieht, dass Qwen GPU/RAM braucht.
- Wenn nicht genug VRAM frei ist, sucht Nap idle GPU-Services.
- Flux kann gestoppt werden, wenn er als idle gilt.
- Qwen wird mit `docker start qwen` gestartet.
- Nap wartet auf Qwen Healthcheck.
- Danach wird der Request an `127.0.0.1:8093` weitergeleitet.

Pruefen:

```sh
napctl --node blackwell service ls
napctl --node blackwell service inspect flux
napctl --node blackwell service inspect qwen-image
napctl --node blackwell service plan qwen-image
napctl --node blackwell host inspect
```

Auf `blackwell`:

```sh
docker ps -a --format 'table {{.Names}}\t{{.Status}}\t{{.Ports}}'
nvidia-smi
sudo journalctl -u napd -n 250 --no-pager
```

## 11. Variante: Flux Laeuft Bereits Vor Nap

Deine bisherige Arbeitsweise war:

```sh
cd /opt/ai/compose/flux
docker compose up -d

cd /opt/ai/compose/flux
docker compose down

cd /opt/ai/compose/qwen
docker compose up -d
```

Mit Nap soll das anders werden:

```sh
cd /opt/ai/compose/flux
docker compose up -d

cd /opt/ai/compose/qwen
docker compose up -d

docker stop qwen
# flux darf fuer diese Variante laufen
```

Dann:

```sh
napctl --node blackwell service ls
napctl --node blackwell host inspect
napctl --node blackwell service plan qwen-image
curl -v -H 'Host: qwen.nap.local' http://192.168.2.211:8787/
```

Wichtig: Nap ist bei Preemption konservativ. Es stoppt nur Services, die in
`nap.yaml` bekannt sind. Flux ist bekannt, also kann er Kandidat sein. Wenn Flux
aber gerade aktiv Traffic bekommen hat, wird er nicht als idle behandelt.

Wenn Flux manuell gestartet wurde und Nap noch keine Aktivitaet gesehen hat,
kann er beim Start von Qwen trotzdem als Preemption-Kandidat auftauchen. Genau
das pruefen wir mit:

```sh
napctl --node blackwell service plan qwen-image --json
```

## 12. Was Bei Problemen Wichtig Ist

MacBook:

```sh
napctl --node blackwell doctor
napctl --node blackwell host inspect --json
napctl --node blackwell service ls --json
napctl --node blackwell service plan qwen-image --json
napctl --node blackwell service logs flux
napctl --node blackwell service logs qwen-image
```

`blackwell`:

```sh
sudo journalctl -u napd -n 300 --no-pager
docker ps -a --format 'table {{.Names}}\t{{.Status}}\t{{.Ports}}'
docker inspect flux
docker inspect qwen
docker logs --tail 100 flux
docker logs --tail 100 qwen
nvidia-smi
```

Netzwerk vom MacBook:

```sh
curl -v http://192.168.2.211:8788/
curl -v -H 'Host: flux.nap.local' http://192.168.2.211:8787/generate
curl -v -H 'Host: qwen.nap.local' http://192.168.2.211:8787/
```

Wenn `8788` direkt per curl `404` liefert, aber `napctl --node blackwell doctor`
funktioniert, ist das okay. Dann ist `napctl` die relevante Pruefung.

## 13. Erfolgskriterien

Der Test ist erfolgreich, wenn:

- MacBook `napctl` verbindet sich mit `blackwell`.
- `host inspect` sieht Docker, RAM und NVIDIA GPU.
- `service ls` sieht `flux` und `qwen-image`.
- Nap kann `flux` mit `docker start flux` wecken.
- Nap kann `qwen` mit `docker start qwen` wecken.
- Bei VRAM-Knappheit stoppt Nap einen idle GPU-Service, bevor Qwen startet.
- Das TUI bleibt bedienbar und zeigt genug Kontext.

Wenn Backend funktioniert, aber die Bubble Tea UI schlecht lesbar ist, behalten
wir die Config und fixen danach gezielt das TUI.

## 14. Spaetere Haertung

Nach dem lokalen Funktionstest sollten wir:

- Remote Control API nicht dauerhaft plain HTTP lassen.
- Caddy/Nginx fuer HTTPS vor `127.0.0.1:8788` setzen.
- `agent.remote.listen` wieder auf `127.0.0.1:8788` begrenzen.
- MacBook `napctl` auf `https://blackwell.local` oder eine echte interne Domain
  konfigurieren.
- Optional Pfad-basiertes Routing im Nap Gateway ergaenzen, falls du spaeter
  unbedingt weiter `/flux/...` und `/qwen/...` direkt ueber Nap statt Caddy
  nutzen willst.
