# Testing Nap on Linux

This guide is for local testing before packages exist. Ubuntu is the first reference target, but the same flow should apply to most systemd-based Linux distributions with Docker Engine.

## Build

```sh
go build -o ./bin/napctl ./cmd/napctl
go build -o ./bin/napd ./cmd/napd
```

## Prepare Config

```sh
./bin/napctl --config nap.yaml init
./bin/napctl --config nap.yaml config validate
```

## Prepare Test Container

```sh
docker run -d --name nap-nginx -p 18080:80 nginx:alpine
docker stop nap-nginx
```

## Run Manually

Terminal 1:

```sh
./bin/napd --config nap.yaml --socket /tmp/napd.sock --log-level debug
```

Terminal 2:

```sh
./bin/napctl --config nap.yaml --socket /tmp/napd.sock doctor
./bin/napctl --config nap.yaml --socket /tmp/napd.sock host inspect
./bin/napctl --config nap.yaml --socket /tmp/napd.sock service ls
./bin/napctl --config nap.yaml --socket /tmp/napd.sock service inspect web
./bin/napctl --config nap.yaml node ls
curl -H 'Host: web.nap.local' http://127.0.0.1:8787
./bin/napctl --config nap.yaml --socket /tmp/napd.sock
```

Expected smoke-test result:

- `napctl service ls` shows `web` as `exited` before the HTTP request.
- The gateway request returns HTTP `200` with the Nginx welcome page.
- `napctl service ls` shows `web` as `running` after the HTTP request.

Cleanup:

```sh
docker rm -f nap-nginx
```

## Generate systemd Unit

```sh
./bin/napctl install systemd \
  --binary /usr/local/bin/napd \
  --config-path /etc/nap/nap.yaml \
  --socket-path /run/nap/napd.sock \
  --output napd.service
```

Review `napd.service` before installing it.

## Generate Remote Agent systemd Unit

For a server controlled from another machine, keep the remote listener bound to localhost and put TLS in front with Caddy/Nginx.

Generate a bearer token first:

```sh
./bin/napctl token --env NAP_REMOTE_TOKEN
```

```sh
./bin/napctl install systemd \
  --binary /usr/local/bin/napd \
  --config-path /etc/nap/nap.yaml \
  --socket-path /run/nap/napd.sock \
  --remote-listen 127.0.0.1:8788 \
  --remote-token-env NAP_REMOTE_TOKEN \
  --env-file /etc/nap/napd.env \
  --output napd.service
```

Example `/etc/nap/napd.env`:

```sh
NAP_REMOTE_TOKEN=generated-value
```
