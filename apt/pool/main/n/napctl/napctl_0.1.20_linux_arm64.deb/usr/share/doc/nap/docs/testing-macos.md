# Testing Nap on macOS

This guide is for local testing with Docker Desktop or Colima.

## Build

```sh
go build -o ./bin/napctl ./cmd/napctl
go build -o ./bin/napd ./cmd/napd
```

## Prepare Config

```sh
./bin/napctl --config nap.yaml init
./bin/napctl --config nap.yaml config validate
```

## Prepare Test Container

```sh
docker run -d --name nap-nginx -p 18080:80 nginx:alpine
docker stop nap-nginx
```

## Run Manually

Terminal 1:

```sh
./bin/napd --config nap.yaml --socket /tmp/napd.sock --log-level debug
```

Terminal 2:

```sh
./bin/napctl --config nap.yaml --socket /tmp/napd.sock doctor
./bin/napctl --config nap.yaml --socket /tmp/napd.sock host inspect
./bin/napctl --config nap.yaml --socket /tmp/napd.sock service ls
./bin/napctl --config nap.yaml node ls
curl -H 'Host: web.nap.local' http://127.0.0.1:8787
./bin/napctl --config nap.yaml --socket /tmp/napd.sock
```

Expected smoke-test result:

- `napctl service ls` shows `web` as `exited` before the HTTP request.
- The gateway request returns HTTP `200` with the Nginx welcome page.
- `napctl service ls` shows `web` as `running` after the HTTP request.

Cleanup:

```sh
docker rm -f nap-nginx
```

## Generate launchd Plist

```sh
./bin/napctl install launchd \
  --binary /usr/local/bin/napd \
  --config-path /usr/local/etc/nap/nap.yaml \
  --socket-path /tmp/napd.sock \
  --output dev.nap.napd.plist
```

Review `dev.nap.napd.plist` before loading it.

## Generate Remote Agent launchd Plist

```sh
./bin/napctl install launchd \
  --binary /usr/local/bin/napd \
  --config-path /usr/local/etc/nap/nap.yaml \
  --socket-path /tmp/napd.sock \
  --remote-listen 127.0.0.1:8788 \
  --remote-token-env NAP_REMOTE_TOKEN \
  --output dev.nap.napd.plist
```

For launchd, provide `NAP_REMOTE_TOKEN` through your launch environment or a later dedicated plist environment block before loading the service.
