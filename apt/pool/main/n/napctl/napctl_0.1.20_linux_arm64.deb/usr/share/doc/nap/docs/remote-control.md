# Remote Control

Remote control lets `napctl` on one machine talk to `napd` on another.

Recommended first production shape:

```text
napctl
  |
  | HTTPS
  v
Caddy/Nginx
  |
  | localhost HTTP
  v
napd remote control API
```

## Agent Config

Generate a bearer token:

```sh
napctl token --env NAP_REMOTE_TOKEN
```

Store the generated value in `/etc/nap/napd.env` on the server:

```sh
NAP_REMOTE_TOKEN=generated-value
```

```yaml
agent:
  socket: /run/nap/napd.sock
  remote:
    listen: 127.0.0.1:8788
    token_env: NAP_REMOTE_TOKEN
```

For direct TLS without a reverse proxy:

```yaml
agent:
  socket: /run/nap/napd.sock
  remote:
    listen: 0.0.0.0:8788
    token_env: NAP_REMOTE_TOKEN
    cert_file: /etc/nap/tls/server.crt
    key_file: /etc/nap/tls/server.key
```

## Client Config

```yaml
nodes:
  ubuntu-gpu:
    type: remote
    url: https://nap.example.com
    token_env: NAP_UBUNTU_TOKEN
```

Remote nodes must configure either `token_env` or `token`. `token_env` is
preferred so secrets stay outside `nap.yaml`.

## Caddy Example

```caddyfile
nap.example.com {
    reverse_proxy 127.0.0.1:8788
}
```

## Nginx Example

```nginx
server {
    listen 443 ssl http2;
    server_name nap.example.com;

    location / {
        proxy_pass http://127.0.0.1:8788;
        proxy_set_header Host $host;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto https;
    }
}
```

## Test

```sh
export NAP_UBUNTU_TOKEN='generated-value'
napctl --node ubuntu-gpu doctor
napctl --node ubuntu-gpu service ls
```
