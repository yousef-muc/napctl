# Release and Packaging

Nap releases should ship both binaries:

- `napctl`
- `napd`

This is intentional. A package install does not decide the role of the machine. A client-only MacBook may only use `napctl`; a Linux server with Docker and GPUs will run `napd`; a local workstation may use both.

## Local Snapshot

```sh
goreleaser release --snapshot --clean
```

Expected artifacts:

- tarballs for macOS and Linux
- checksums
- `.deb`
- `.rpm`
- generated Homebrew formula at `dist/homebrew/napctl.rb`

Useful local checks:

```sh
tar -tzf dist/napctl_VERSION_darwin_arm64.tar.gz
shasum -a 256 -c dist/checksums.txt
ruby -c dist/homebrew/napctl.rb
```

When running snapshots outside a Git repository, GoReleaser accepts the build
but uses placeholder GitHub URLs in the generated Homebrew formula. Tagged
releases must run from the real Git repository so release URLs and commit
metadata are populated correctly.

## Homebrew

Expected user flow:

```sh
brew install napctl
```

This installs both `napctl` and `napd`.

The generated formula supports:

```sh
brew services start napctl
```

GoReleaser currently recommends `homebrew_casks` for prebuilt binaries, but Nap
keeps a formula publisher for now because the intended user experience is
`brew install napctl` rather than `brew install --cask napctl`.
The GitHub workflow pins GoReleaser to the locally verified v2 release line so a
future removal of deprecated formula generation does not unexpectedly break tag
releases.

Typical client-only use:

```sh
napctl --node ubuntu-gpu service ls
```

If the Mac should also run local workloads, `napd` can be started manually or later through Homebrew services.

## Linux Packages

Expected user flow:

```sh
curl -fsSL https://yousef-muc.github.io/napctl/install.sh | sh
```

Debian and Ubuntu users can also configure the signed APT repository manually:

```sh
sudo install -d -m 0755 /usr/share/keyrings
curl -fsSL https://yousef-muc.github.io/napctl/apt/gpg/napctl.gpg | sudo tee /usr/share/keyrings/napctl-archive-keyring.gpg >/dev/null
echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/napctl-archive-keyring.gpg] https://yousef-muc.github.io/napctl/apt stable main" | sudo tee /etc/apt/sources.list.d/napctl.list >/dev/null
sudo apt update
sudo apt install napctl
```

RPM-based distributions can configure the generated DNF/YUM repository:

```sh
sudo curl -fsSL https://yousef-muc.github.io/napctl/rpm/napctl.repo -o /etc/yum.repos.d/napctl.repo
sudo dnf install napctl
```

Direct package installation remains available as a fallback:

```sh
sudo apt install ./napctl_VERSION_linux_amd64.deb
sudo rpm -i ./napctl_VERSION_linux_amd64.rpm
```

Packages install:

```text
/usr/bin/napctl
/usr/bin/napd
/etc/nap/nap.yaml
/lib/systemd/system/napd.service      # deb
/usr/lib/systemd/system/napd.service  # rpm
```

Package sanity checks:

```sh
napctl version
napd --version
napctl --config /etc/nap/nap.yaml config validate
```

Enable the agent only on hosts that should manage Docker workloads:

```sh
sudo usermod -aG docker nap
sudo usermod -aG nap "$USER"
sudo systemctl enable --now napd
```

Client-only Linux hosts can leave `napd` disabled and use only `napctl`.

The packaged systemd service uses `NAP_LOG_LEVEL=info` by default and reads
optional overrides from `/etc/nap/napd.env`.

The release workflow also publishes static Linux package repositories to the
public distribution repository's `gh-pages` branch:

```text
https://yousef-muc.github.io/napctl/apt
https://yousef-muc.github.io/napctl/rpm
```

APT metadata is signed with `InRelease` and `Release.gpg`. RPM repository
metadata is signed through `repomd.xml.asc`, and RPM packages are signed during
the nFPM package build. The generated `napctl.repo` enables both
`repo_gpgcheck=1` and `gpgcheck=1`.

## GitHub Release

Tag releases are built through GoReleaser:

```sh
git push origin main
git tag v0.1.3
git push origin v0.1.3
```

A normal `git push origin main` does not publish a user-facing version. It only
updates the private source repository. Publishing requires a new `v*` tag.

When the tag workflow succeeds, it publishes the GitHub release, Homebrew
formula, APT repository, DNF/YUM repository, and checksums automatically. No
manual asset copying is required.

The source repository can stay private. The workflow publishes archives,
checksums, `.deb`, and `.rpm` artifacts to the public distribution repository:

```text
https://github.com/yousef-muc/napctl
```

The Homebrew tap formula points at that public release repository, so package
managers can download release assets without access to the private source code.

The private source repository needs a `HOMEBREW_TAP_GITHUB_TOKEN` repository
secret. The token is used for public release publishing, Homebrew tap updates,
and Linux repository publishing, so it needs write access to:

```text
yousef-muc/napctl
yousef-muc/homebrew-tap
```

Linux repository signing uses:

```text
LINUX_REPO_GPG_PRIVATE_KEY
LINUX_REPO_GPG_PASSPHRASE  # optional
```

The same signing key is used for APT repository metadata, RPM repository
metadata, and RPM package signatures.
