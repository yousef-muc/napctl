# Installation Model

Nap ships two binaries:

- `napctl`: CLI/TUI client
- `napd`: host agent, control API, gateway, and Docker orchestrator

The same package can install both binaries. You only run `napd` on machines that should manage Docker workloads.

## macOS

Expected Homebrew UX:

```sh
brew install napctl
```

This installs:

```text
/opt/homebrew/bin/napctl
/opt/homebrew/bin/napd
```

Typical MacBook client-only use:

```sh
napctl node ls
napctl --node ubuntu-gpu service ls
napctl --node ubuntu-gpu
```

If the Mac also runs local Docker workloads, `napd` can be run manually or via launchd:

```sh
napctl install launchd --output dev.nap.napd.plist
```

Later Homebrew service UX should look like:

```sh
brew services start napctl
```

Homebrew service config lives at:

```text
$(brew --prefix)/etc/nap/nap.yaml
```

When `--config` is not provided, `napctl` looks for configuration in this order:

```text
./nap.yaml
~/Library/Application Support/nap/nap.yaml
/opt/homebrew/etc/nap/nap.yaml
/usr/local/etc/nap/nap.yaml
/etc/nap/nap.yaml
```

Show the resolved path with:

```sh
napctl config path
```

## Linux

Recommended one-line installer:

```sh
curl -fsSL https://yousef-muc.github.io/napctl/install.sh | sh
```

Debian and Ubuntu repository setup:

```sh
sudo install -d -m 0755 /usr/share/keyrings
curl -fsSL https://yousef-muc.github.io/napctl/apt/gpg/napctl.gpg | sudo tee /usr/share/keyrings/napctl-archive-keyring.gpg >/dev/null
echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/napctl-archive-keyring.gpg] https://yousef-muc.github.io/napctl/apt stable main" | sudo tee /etc/apt/sources.list.d/napctl.list >/dev/null
sudo apt update
sudo apt install napctl
```

RPM repository setup:

```sh
sudo curl -fsSL https://yousef-muc.github.io/napctl/rpm/napctl.repo -o /etc/yum.repos.d/napctl.repo
sudo dnf install napctl
```

Direct package installation remains available as a fallback:

```sh
sudo apt install ./napctl_VERSION_linux_amd64.deb
sudo dnf install ./napctl_VERSION_linux_amd64.rpm
```

The package should install:

```text
/usr/bin/napctl
/usr/bin/napd
/etc/nap/nap.yaml
/lib/systemd/system/napd.service
```

Check installed versions:

```sh
napctl version
napd --version
```

On a Docker/GPU server:

```sh
sudo usermod -aG docker nap
sudo usermod -aG nap "$USER"
sudo systemctl enable --now napd
```

The packaged service runs as the dedicated `nap` user. That user must be allowed
to access the local Docker socket on hosts that should run workloads.
Users who should run `napctl` locally against the packaged system service should
be members of the `nap` group, then start a new login shell.

Optional service environment overrides live in:

```text
/etc/nap/napd.env
```

For example:

```sh
NAP_LOG_LEVEL=debug
NAP_REMOTE_TOKEN=replace-with-generated-token
```

On a client-only Linux machine, use `napctl` without enabling `napd`.

When `--config` is not provided, `napctl` looks for configuration in this order:

```text
./nap.yaml
~/.config/nap/nap.yaml
/opt/homebrew/etc/nap/nap.yaml
/usr/local/etc/nap/nap.yaml
/etc/nap/nap.yaml
```

Show the resolved path with:

```sh
napctl config path
```

## Split Machine Setup

```text
MacBook
  napctl
    |
    | HTTPS + bearer token
    v
Linux server
  napd
    ├── control API
    ├── gateway
    └── Docker/GPU workloads
```

The gateway and Docker orchestration always run where Docker and the GPUs are.
