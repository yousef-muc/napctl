# Operations

`napctl host inspect` asks the selected `napd` host for runtime and resource
information. The command works for local Unix-socket nodes and remote HTTP(S)
nodes.

```sh
napctl host inspect
napctl host inspect --json
napctl --node ubuntu-gpu host inspect
napctl --node ubuntu-gpu --timeout 15s host inspect
```

`--timeout` is optional and applies to a single command. Leave it unset for
interactive TUI sessions or long-running log streaming.

Current host discovery includes:

- Docker runtime metadata from `docker info`
- CPU count and host memory
- NVIDIA GPU discovery through `nvidia-smi`, including GPU index, name, VRAM,
  and utilization
- NVIDIA compute-process discovery through `nvidia-smi`, including PID, process
  name, and per-process VRAM usage where the driver exposes it
- Linux Docker container attribution for GPU processes through `/proc/<pid>/cgroup`
  and `docker inspect`, including container ID and name when available

This is the base for scheduler decisions, GPU-aware service placement, and richer
TUI status panels.

## Service Requirements

Services can declare resource requirements in `nap.yaml`:

```yaml
services:
  ollama:
    host: ollama.example.com
    # Optional Host header presented to the upstream application.
    # upstream_host: public.example.com
    container: ollama
    target: http://127.0.0.1:11434
    healthcheck:
      url: http://127.0.0.1:11434/api/tags
      timeout: 60s
      interval: 1s
    resources:
      cpus: 4
      memory: 16GiB
      gpus:
        count: 1
        vendor: nvidia
        min_vram: 8GiB
    idle: 5m
    idle_shutdown: true
    stop_timeout: 30s
```

`host` selects the service at the Nap gateway. Optional `upstream_host` changes
only the Host header seen by the proxied application, which keeps routing and
browser-origin handling separate. Its value is a host or host plus port without
a URL scheme. If `upstream_host` is omitted, Nap preserves the existing behavior
and forwards the routing host.

`idle_shutdown` defaults to `true`. Set it to `false` to disable automatic
time-based shutdown for that service. This does not pin the container: when the
service has no active request and another workload needs its resources, it can
still be selected for resource preemption.

`napctl doctor` checks these requirements against the selected host. This does
not yet create or move containers; it establishes the production config model
needed for GPU-aware scheduling and placement.

Explain a start decision without starting or stopping containers:

```sh
napctl service plan ollama
napctl service plan ollama --json
napctl --node ubuntu-gpu service plan ollama
```

The plan response includes whether the service can start, the resource message,
and any idle preemption candidates sorted by attributed VRAM usage.

Gateway wake-up waits for an optional service healthcheck before proxying the
original request. A healthcheck is considered ready only for HTTP `2xx` and
`3xx` responses; `4xx` and `5xx` responses keep the service in the wait loop
until the configured timeout is reached.

Compare the same service across every configured node:

```sh
napctl node plan ollama
napctl node plan ollama --json
```

This is a dry run for multi-node placement. It does not start, stop, or move
containers; it asks each configured `napd` how that node would handle the
service. The text output marks the current best candidate with `*`. Ranking
prefers nodes that can start without preemption, then nodes with fewer
preemption candidates, then stable node-name ordering.

Start on the best ranked node:

```sh
napctl node start ollama
napctl node start ollama --json
```

This uses the same ranking as `node plan`, then asks only the selected node to
start the service. Any preemption still happens inside that node's `napd`, where
Docker and the GPUs live.

## Scheduling Cases

The scheduling logic runs inside `napd`, so the same behavior applies whether
`napctl` is on the same machine, in the LAN, or connects over HTTPS to a remote
server.

### One Local Machine, One GPU

`napctl`, `napd`, Docker, and the GPU are on the same host. When an HTTP request
wakes a sleeping service, `napd` checks configured CPU/RAM/GPU requirements
against the host. If GPU VRAM is not available, `napd` can stop idle configured
GPU services and retry the resource check before starting the requested
container.

### One Local Machine, Multiple GPUs

The same flow applies, but `napd` checks every detected GPU. Services can request
any matching GPU, a vendor, a minimum VRAM amount, or explicit GPU indices.

### LAN Nodes

`napctl` can target one or more LAN agents with `--node`. Each `napd` makes local
scheduling decisions for its own Docker host and GPUs.

### Remote Datacenter Nodes

Remote nodes work like LAN nodes, but should use HTTPS with a bearer token or
native TLS on the remote control API. Scheduling still happens on the host where
Docker and the GPUs live.

Current preemption is intentionally conservative: it only considers services
known in `nap.yaml`, only stops running services with GPU requirements, and uses
Nap activity timestamps to determine idleness. On Linux/NVIDIA hosts, Nap now
uses GPU process-to-container attribution to prefer stopping idle services that
are actually consuming VRAM. Services without visible attribution remain a
fallback, so setups still work when drivers or container runtimes expose less
detail.
